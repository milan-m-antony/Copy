// This file is no longer needed as legal content is shown in modals from the footer.
// Marked for deletion.
